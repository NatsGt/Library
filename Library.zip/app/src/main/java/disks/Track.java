package disks;

public class Track {

  private String title;
  private String artist;
  private int duration;

  public Track(String title, String artist, int duration) {
    this.title = title;
    this.artist = artist;
    this.duration = duration;
  }

  public String getTitle() {
    return title;
  }

  public String getArtist() {
    return artist;
  }

  public int getDuration() {
    return duration;
  }
}
